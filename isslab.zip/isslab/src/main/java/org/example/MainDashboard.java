package org.example;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MainDashboard extends JFrame {
    private JLabel lblSoldTotal;
    private JTable tabelTranzactii;
    private DefaultTableModel tableModel;

    public MainDashboard() {
        setTitle("BudgetInsight - Dashboard");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));


        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(41, 128, 185));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblSoldTotal = new JLabel("Sold Total: 4,520.50 RON");
        lblSoldTotal.setFont(new Font("Arial", Font.BOLD, 28));
        lblSoldTotal.setForeground(Color.WHITE);
        topPanel.add(lblSoldTotal);


        String[] coloane = {"ID", "Dată", "Descriere", "Categorie", "Cont", "Tip", "Sumă (RON)"};

        Object[][] dateTest = {
                {1, "2026-11-01", "Salariu", "Venituri", "BT", "VENIT", "+ 6500.00"},
                {2, "2026-11-02", "Chirie", "Locuinta", "Revolut", "CHELTUIALA", "- 1500.00"},
                {3, "2026-11-05", "Supermarket", "Mancare", "Revolut", "CHELTUIALA", "- 350.50"},
                {4, "2026-11-10", "Abonament Sala", "Sanatate", "BT", "CHELTUIALA", "- 129.00"}
        };

        tableModel = new DefaultTableModel(dateTest, coloane);
        tabelTranzactii = new JTable(tableModel);
        tabelTranzactii.setRowHeight(25);
        tabelTranzactii.setFont(new Font("SansSerif", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(tabelTranzactii);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Ultimele Tranzacții"));


        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));

        JButton btnAddTranzactie = new JButton("Adaugă Tranzacție");
        btnAddTranzactie.setBackground(new Color(46, 204, 113));
        btnAddTranzactie.setForeground(Color.WHITE);
        btnAddTranzactie.setFocusPainted(false);
        btnAddTranzactie.setFont(new Font("Arial", Font.BOLD, 14));

        JButton btnCategorii = new JButton("Gestiune Categorii");


        btnAddTranzactie.addActionListener(e -> {
            TransactionDialog dialog = new TransactionDialog(this);
            dialog.setVisible(true);
        });

        bottomPanel.add(btnCategorii);
        bottomPanel.add(btnAddTranzactie);


        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}