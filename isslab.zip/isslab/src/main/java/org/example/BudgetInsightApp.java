package org.example;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class BudgetInsightApp {

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }


        SwingUtilities.invokeLater(MainDashboard::new);
    }
}