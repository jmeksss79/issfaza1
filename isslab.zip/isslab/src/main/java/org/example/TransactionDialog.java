package org.example;

import javax.swing.*;
import java.awt.*;

public class TransactionDialog extends JDialog {
    private JTextField txtSuma, txtData, txtDescriere;
    private JComboBox<String> cbCategorie, cbCont, cbTip;

    public TransactionDialog(JFrame parent) {
        super(parent, "Adaugă Tranzacție", true);
        setSize(400, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));


        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 15));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        formPanel.add(new JLabel("Tip Tranzacție:"));
        cbTip = new JComboBox<>(new String[]{"Cheltuială", "Venit"});
        formPanel.add(cbTip);

        formPanel.add(new JLabel("Sumă (RON):"));
        txtSuma = new JTextField();
        formPanel.add(txtSuma);

        formPanel.add(new JLabel("Dată (YYYY-MM-DD):"));
        txtData = new JTextField("2023-11-15");
        formPanel.add(txtData);

        formPanel.add(new JLabel("Descriere:"));
        txtDescriere = new JTextField();
        formPanel.add(txtDescriere);

        formPanel.add(new JLabel("Categorie:"));
        cbCategorie = new JComboBox<>(new String[]{"Mâncare", "Chirie", "Mașină", "Sănătate", "Venituri"});
        formPanel.add(cbCategorie);

        formPanel.add(new JLabel("Cont:"));
        cbCont = new JComboBox<>(new String[]{"Revolut", "Banca Transilvania", "Cash"});
        formPanel.add(cbCont);


        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvare = new JButton("Salvează");
        JButton btnCancel = new JButton("Anulează");

        btnSalvare.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Tranzacție salvată cu succes!\n(În iterațiile viitoare va fi scrisă în DB)", "Succes", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        });

        btnCancel.addActionListener(e -> dispose());

        btnPanel.add(btnCancel);
        btnPanel.add(btnSalvare);

        add(formPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }
}