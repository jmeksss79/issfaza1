package service;

import model.Categorie;
import repository.IRepoCategorii;
import java.util.List;

public class ServiciuCategorii {
    private IRepoCategorii repoCat;

    public ServiciuCategorii(IRepoCategorii repoCat) {
        this.repoCat = repoCat;
        initializareDefault();
    }

    public void creeazaCategorie(String nume) {
        repoCat.save(new Categorie(nume));
    }

    public List<Categorie> getToateCategoriile() {
        return repoCat.findAll();
    }

    private void initializareDefault() {
        if (repoCat.findAll().isEmpty()) {
            creeazaCategorie("Mancare");
            creeazaCategorie("Chirie");
            creeazaCategorie("Salariu");
        }
    }
}