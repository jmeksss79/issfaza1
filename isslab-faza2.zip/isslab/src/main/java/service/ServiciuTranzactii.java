package service;

import model.TipTranzactie;
import model.Tranzactie;
import repository.IRepoTranzactii;
import java.util.List;

public class ServiciuTranzactii {
    private IRepoTranzactii repoT;

    public ServiciuTranzactii(IRepoTranzactii repoT) {
        this.repoT = repoT;
    }

    public void adaugaTranzactie(Tranzactie t) throws Exception {
        if (t.getSuma() <= 0) throw new Exception("Suma trebuie să fie pozitivă.");
        repoT.save(t);
    }

    public List<Tranzactie> getToateTranzactiile() {
        return repoT.findAll();
    }

    public double calculeazaSoldTotal() {
        double sold = 0;
        for (Tranzactie t : repoT.findAll()) {
            if (t.getTip() == TipTranzactie.VENIT) sold += t.getSuma();
            else sold -= t.getSuma();
        }
        return sold;
    }
}