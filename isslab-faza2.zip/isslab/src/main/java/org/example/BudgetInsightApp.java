package org.example;

import repository.RepoCategoriiImpl;
import repository.RepoTranzactiiImpl;
import service.ServiciuCategorii;
import service.ServiciuTranzactii;
import ui.MainDashboard;
import javax.swing.*;

public class BudgetInsightApp {
    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception e) { e.printStackTrace(); }

        // Dependency Injection manual
        RepoCategoriiImpl repoCategorii = new RepoCategoriiImpl();
        RepoTranzactiiImpl repoTranzactii = new RepoTranzactiiImpl();

        ServiciuCategorii srvCategorii = new ServiciuCategorii(repoCategorii);
        ServiciuTranzactii srvTranzactii = new ServiciuTranzactii(repoTranzactii);

        SwingUtilities.invokeLater(() -> new MainDashboard(srvTranzactii, srvCategorii));
    }
}