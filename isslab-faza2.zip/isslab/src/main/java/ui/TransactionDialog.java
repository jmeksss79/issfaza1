package ui;

import model.Categorie;
import model.TipTranzactie;
import model.Tranzactie;
import service.ServiciuCategorii;
import service.ServiciuTranzactii;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class TransactionDialog extends JDialog {
    private JTextField txtSuma, txtData, txtDescriere;
    private JComboBox<Categorie> cbCategorie;
    private JComboBox<String> cbTip;

    public TransactionDialog(JFrame parent, ServiciuTranzactii srvTranzactii, ServiciuCategorii srvCategorii) {
        super(parent, "Adaugă Tranzacție", true);
        setSize(400, 350);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 15));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        formPanel.add(new JLabel("Tip Tranzacție:"));
        cbTip = new JComboBox<>(new String[]{"Cheltuială", "Venit"});
        formPanel.add(cbTip);

        formPanel.add(new JLabel("Sumă (RON):"));
        txtSuma = new JTextField();
        formPanel.add(txtSuma);

        formPanel.add(new JLabel("Dată (YYYY-MM-DD):"));
        txtData = new JTextField(LocalDate.now().toString());
        formPanel.add(txtData);

        formPanel.add(new JLabel("Descriere:"));
        txtDescriere = new JTextField();
        formPanel.add(txtDescriere);

        formPanel.add(new JLabel("Categorie:"));
        cbCategorie = new JComboBox<>();
        for (Categorie c : srvCategorii.getToateCategoriile()) {
            cbCategorie.addItem(c);
        }
        formPanel.add(cbCategorie);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSalvare = new JButton("Salvează");
        JButton btnCancel = new JButton("Anulează");

        btnSalvare.addActionListener(e -> {
            try {
                Double suma = Double.parseDouble(txtSuma.getText());
                LocalDate data = LocalDate.parse(txtData.getText());
                String descriere = txtDescriere.getText();
                TipTranzactie tip = cbTip.getSelectedItem().equals("Venit") ? TipTranzactie.VENIT : TipTranzactie.CHELTUIALA;
                Categorie cat = (Categorie) cbCategorie.getSelectedItem();

                srvTranzactii.adaugaTranzactie(new Tranzactie(suma, descriere, data, tip, cat));
                JOptionPane.showMessageDialog(this, "Tranzacție salvată cu succes!");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Eroare: " + ex.getMessage(), "Eroare", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> dispose());

        btnPanel.add(btnCancel);
        btnPanel.add(btnSalvare);

        add(formPanel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);
    }
}