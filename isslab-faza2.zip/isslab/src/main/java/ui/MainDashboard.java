package ui;

import model.TipTranzactie;
import model.Tranzactie;
import service.ServiciuCategorii;
import service.ServiciuTranzactii;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MainDashboard extends JFrame {
    private JLabel lblSoldTotal;
    private JTable tabelTranzactii;
    private DefaultTableModel tableModel;
    private ServiciuTranzactii srvTranzactii;
    private ServiciuCategorii srvCategorii;

    public MainDashboard(ServiciuTranzactii srvTranzactii, ServiciuCategorii srvCategorii) {
        this.srvTranzactii = srvTranzactii;
        this.srvCategorii = srvCategorii;

        setTitle("BudgetInsight - Dashboard");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(41, 128, 185));
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblSoldTotal = new JLabel("Sold Total: 0.00 RON");
        lblSoldTotal.setFont(new Font("Arial", Font.BOLD, 28));
        lblSoldTotal.setForeground(Color.WHITE);
        topPanel.add(lblSoldTotal);

        String[] coloane = {"ID", "Dată", "Descriere", "Categorie", "Tip", "Sumă"};
        tableModel = new DefaultTableModel(null, coloane);
        tabelTranzactii = new JTable(tableModel);
        tabelTranzactii.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(tabelTranzactii);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Ultimele Tranzacții"));

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        JButton btnAddTranzactie = new JButton("Adaugă Tranzacție");
        btnAddTranzactie.setBackground(new Color(46, 204, 113));
        btnAddTranzactie.setForeground(Color.WHITE);

        btnAddTranzactie.addActionListener(e -> {
            new TransactionDialog(this, srvTranzactii, srvCategorii).setVisible(true);
            incarcaDate();
        });

        bottomPanel.add(btnAddTranzactie);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        incarcaDate();
        setVisible(true);
    }

    private void incarcaDate() {
        tableModel.setRowCount(0);
        for (Tranzactie t : srvTranzactii.getToateTranzactiile()) {
            String semn = t.getTip() == TipTranzactie.VENIT ? "+ " : "- ";
            tableModel.addRow(new Object[]{
                    t.getId(), t.getData(), t.getDescriere(), t.getCategorie().getNume(), t.getTip().name(), semn + t.getSuma()
            });
        }
        lblSoldTotal.setText(String.format("Sold Total: %.2f RON", srvTranzactii.calculeazaSoldTotal()));
    }
}