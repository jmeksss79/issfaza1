package repository;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class HibernateUtil {
    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("budgetPU");
    public static EntityManagerFactory getEntityManagerFactory() { return emf; }
}