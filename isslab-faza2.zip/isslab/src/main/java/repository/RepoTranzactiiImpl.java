package repository;

import jakarta.persistence.EntityManager;
import model.Tranzactie;
import java.util.List;

public class RepoTranzactiiImpl implements IRepoTranzactii {
    @Override
    public void save(Tranzactie t) {
        EntityManager em = HibernateUtil.getEntityManagerFactory().createEntityManager();
        em.getTransaction().begin();
        em.persist(t);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public List<Tranzactie> findAll() {
        EntityManager em = HibernateUtil.getEntityManagerFactory().createEntityManager();
        List<Tranzactie> list = em.createQuery("SELECT t FROM Tranzactie t", Tranzactie.class).getResultList();
        em.close();
        return list;
    }
}