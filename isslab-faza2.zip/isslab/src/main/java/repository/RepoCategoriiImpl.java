package repository;

import jakarta.persistence.EntityManager;
import model.Categorie;
import java.util.List;

public class RepoCategoriiImpl implements IRepoCategorii {
    @Override
    public void save(Categorie c) {
        EntityManager em = HibernateUtil.getEntityManagerFactory().createEntityManager();
        em.getTransaction().begin();
        em.persist(c);
        em.getTransaction().commit();
        em.close();
    }

    @Override
    public List<Categorie> findAll() {
        EntityManager em = HibernateUtil.getEntityManagerFactory().createEntityManager();
        List<Categorie> categorii = em.createQuery("SELECT c FROM Categorie c", Categorie.class).getResultList();
        em.close();
        return categorii;
    }
}