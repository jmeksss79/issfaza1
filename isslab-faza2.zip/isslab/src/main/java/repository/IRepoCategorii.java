package repository;
import model.Categorie;
import java.util.List;

public interface IRepoCategorii {
    void save(Categorie c);
    List<Categorie> findAll();
}