package repository;
import model.Tranzactie;
import java.util.List;

public interface IRepoTranzactii {
    void save(Tranzactie t);
    List<Tranzactie> findAll();
}