package model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tranzactii")
public class Tranzactie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Double suma;

    private String descriere;

    @Column(nullable = false)
    private LocalDate data;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipTranzactie tip;

    @ManyToOne
    @JoinColumn(name = "categorie_id", nullable = false)
    private Categorie categorie;

    public Tranzactie() {}

    public Tranzactie(Double suma, String descriere, LocalDate data, TipTranzactie tip, Categorie categorie) {
        this.suma = suma;
        this.descriere = descriere;
        this.data = data;
        this.tip = tip;
        this.categorie = categorie;
    }

    public Long getId() { return id; }
    public Double getSuma() { return suma; }
    public String getDescriere() { return descriere; }
    public LocalDate getData() { return data; }
    public TipTranzactie getTip() { return tip; }
    public Categorie getCategorie() { return categorie; }
}