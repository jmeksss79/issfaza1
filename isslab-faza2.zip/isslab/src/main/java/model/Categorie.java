package model;

import jakarta.persistence.*;

@Entity
@Table(name = "categorii")
public class Categorie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nume;

    private Double bugetLunar;

    public Categorie() {}
    public Categorie(String nume) { this.nume = nume; }

    public Long getId() { return id; }
    public String getNume() { return nume; }
    public Double getBugetLunar() { return bugetLunar; }
    public void setBugetLunar(Double bugetLunar) { this.bugetLunar = bugetLunar; }

    @Override
    public String toString() { return nume; }
}