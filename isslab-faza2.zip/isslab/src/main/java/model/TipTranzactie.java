package model;

public enum TipTranzactie {
    VENIT, CHELTUIALA
}